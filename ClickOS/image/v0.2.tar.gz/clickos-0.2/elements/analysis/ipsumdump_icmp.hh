#ifndef CLICK_IPSUMDUMP_ICMP_HH
#define CLICK_IPSUMDUMP_ICMP_HH
#include "ipsumdumpinfo.hh"
CLICK_DECLS

class IPSummaryDump_ICMP { public:
    static void static_initialize();
    static void static_cleanup();
};

CLICK_ENDDECLS
#endif
